/*----------------------------------------------------------------\
@ C-Tutorial by Young-Keun Kim - Handong Global University

Author           : Y.K.Kim (20500000)
Created          : 08-30-2024
Modified         : 08-30-2024
Language/ver     : C++ in MSVS2022

Description      : Header definition file for TU_Debugging 
/----------------------------------------------------------------*/

#include "NP_debugging_header.h"

// Subtract two integers
int subtract_int(int a, int b) {
	return a - b;
}

