function J=myJacobEx2_student(Z)

J=zeros(3,3);
th=Z(1);
dx=Z(2);
dy=Z(3);
x0=0; y0=100; x1=0; y1=-100;

% [TO-DO] Define Jacobian
% J=_________;     % 3x3 matrix for this exercise


end