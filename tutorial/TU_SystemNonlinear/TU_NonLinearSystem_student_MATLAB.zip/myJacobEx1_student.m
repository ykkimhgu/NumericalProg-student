function J=myJacobEx1_student(x)

J=zeros(2,2);

% [TO-DO] Define Jacobian
% J=_________;     % 2x2 matrix for this exercise

end