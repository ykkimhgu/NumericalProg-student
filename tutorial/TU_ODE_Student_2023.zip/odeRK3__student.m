function [x, y] = odeRK3__student(ODE,a,b,h,yIni)
% odeRK4 solves a first order initial value ODE using Ronge-Kutta 3rd
% order method.
% Input variables:
% ODE    Name of a function file that calculates dy/dx.
% a      The first value of x.
% b      The last value of x.
% h      Step size.
% yIni     The value of the solution y at the first point (initial value).
% Output variable:
% x      A vector with the x coordinate of the solution points.
% y      A vector with the y coordinate of the solution points. 

x(1) = a;  y(1) = yIni;
n = (b-a)/h;
for i = 1:n
    x(i+1) = x(i) + h;
    K1 = ODE(x(i),y(i));
    
    % [YOUR CODE GOES HERE]
    % [YOUR CODE GOES HERE]
    % [YOUR CODE GOES HERE]

end