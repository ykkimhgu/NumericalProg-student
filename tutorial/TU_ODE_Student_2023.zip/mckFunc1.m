
function [dydt] = mckFunc1(t,y)
dydt=zeros(2,1); % column vector

% %%% example 1
% m=10; k=4000; c=20;
% FinDC=100;

%%% example 2
m=1; k=6.9; c=10*0.7;
FinDC=2;
f=5;

Fin=FinDC*cos(2*pi*f*t);

dydt(1)=y(2);
dydt(2)=1/m*(Fin-c*y(2)-k*y(1));

