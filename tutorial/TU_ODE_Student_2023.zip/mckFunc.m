
function [dydt] = mckFunc(t,y1,y2)
dydt=zeros(2,1); % column vector


% %%% example 1
% m=10; k=4000; c=20;
% FinDC=100;


%%% example 2
m=1; k=6.9; c=10*0.7;
FinDC=2;
f=5;
Fin=FinDC*cos(2*pi*f*t);

% y=y1, z=y2=ydot;
dydt(1)=y2;  % ydot=z
dydt(2)=1/m*(Fin-c*y2-k*y1);  % zdot


