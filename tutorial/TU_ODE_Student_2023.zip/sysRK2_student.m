function [x, y, z] = sysRK2_student(OdeFunc,a,b,h,yINI,zINI)
% SysODEsRK2 solves a system of two first-order initial value ODEs using
% second-order Runge-Kutta method.
% The independent variable is x, and the dependent variables are y and z.
% Input variables:
% OdeFunc   Name of a function file that calculates [dy/dx; dz/dx].
% a      The first value of x.
% b      The last value of x.
% h      The size of a increment.
% yINI     The initial value of y.
% zINI     The initial value of z.
% Output variable:
% x      A vector with the x coordinate of the solution points.
% y      A vector with the y coordinate of the solution points.
% z      A vector with the z coordinate of the solution points.


x(1) = a; y(1) = yINI;  z(1) = zINI;
N = (b - a)/h;

Ky1=0;    Kz1=0;    Ky2=0;    Kz2=0;

for i = 1:N
    x(i+1) = x(i) + h;
    
    ODE = OdeFunc(x(i),y(i), z(i));  
    %Ky1 = ODE(1);
    %Kz1 = ________;
    
    
    %Ky2 =____________;
    %Kz2 =____________;
    
    y(i+1) = y(i) + (Ky1 + Ky2)*h/2;
    z(i+1) = z(i) + (Kz1 + Kz2)*h/2;
end