/*------------------------------------------------------------------------------------------\
@ Numerical Methods by Young-Keun Kim - Handong Global University

Author          : Young-Keun Kim
Created         : 01-04-2019
Modified        : 12-08-2022
Language/ver	: C in MSVS2017
Course			: Numerical Programming 

Description     : TU System of NonLinear
/------------------------------------------------------------------------------------------*/


#include "stdio.h"
#include "stdlib.h"
#include <math.h>

#include "../../../include/myNP.h"


Matrix myFuncEx1(Matrix X);
Matrix myJacobEx1(Matrix X);

void main() {

	/*==========================================================================*/
	/*					Variables declaration & initialization					*/
	/*--------------------------------------------------------------------------*/
	/*   - You can change the variable names									*/
	/*   - However, you must use the specified file name						*/
	/*	   : For each assignment, the file name will be notified on HISNET		*/
	/*==========================================================================*/
	
	/************      Variables declaration & initialization      ************/	
	double loss = 0;	
	double n = 2;
	

	Matrix J = zeros(n, n);
	Matrix F = zeros(n, 1);
	Matrix H = zeros(n, 1);
	Matrix Z = zeros(n, 1);
	
	// Initial condition
	double z0[2] = { 2.5, 2 };
	Z = arr2Mat(z0, n, 1);

	/*==========================================================================*/
	/*					Apply your numerical method algorithm					*/
	/*==========================================================================*/
	
	/* MATLAB CODE
		for k = 1:20
			F = myFuncEx1(Z);
			J = myJacobEx1(Z);		
			H = J\(-F);% do not use inverse. Use Gauss Elimination Ax=b
			Z = Z + H;
			loss = norm(myFuncEx1(Z));
			fprintf("iter =%d \t x=%0.3f \t y=%0.3f \t loss=%0.3f\n", k, Z(1), Z(2), loss)
		end 
	*/

	for (int k = 0; k < 20; k++) {
		F = myFuncEx1(Z);
		J = myJacobEx1(Z);

		// [TO-DO]  YOUR CODE GOES HERE
		// F =-1*F; 
		
		// [TO-DO]  YOUR CODE GOES HERE
		// H = solveLinear( );  // JH=F
		
		// [TO-DO]  YOUR CODE GOES HERE
		// Z=Z+H
		

		// After update, print loss			
		// [TO-DO]  YOUR CODE GOES HERE
		// F = myFuncEx1(Z);
		// loss = norm2(F);

		printf("iter =%d \t x=%0.3f \t y=%0.3f \t loss=%0.3f\n", k, Z.at[0][0], Z.at[1][0], loss);
	}


	/*==========================================================================*/
	/*							  Print your results							*/
	/*==========================================================================*/
	
	printf("----------------------------------------------------------------------------------------------\n");
	printf("			            System of NonLinear							\n");
	printf("----------------------------------------------------------------------------------------------\n");
	
	printMat(Z, "Z");	
	printf("\n\n");

	/*==========================================================================*/
	/*							  Deallocate memory 							*/
	/*==========================================================================*/
	freeMat(J);	freeMat(H);	freeMat(F); 	freeMat(Z);	

	system("pause");
}




/*==========================================================================*/
/*						Function Definitions								*/
/*==========================================================================*/

Matrix myFuncEx1(Matrix X)
{
		
	int n = X.rows;
	Matrix F = zeros(n, 1);

	double x1 = X.at[0][0];
	double x2 = X.at[1][0];
	
	/* MATLAB CODE
		function F = myFuncEx1(x)
			F(1) = x(2) - 0.5 * (exp(x(1) / 2) + exp(-x(1) / 2));
			F(2) = 9 * x(1) ^ 2 + 25 * x(2) ^ 2 - 225;
		end
	*/

	// [TO-DO] YOUR CODE GOES HERE
	// F.at[0][0] =_________________________
	// [TO-DO] YOUR CODE GOES HERE
	// F.at[1][0] =_________________________


	return F;
}


Matrix myJacobEx1(Matrix X)
{

	int n = X.rows;
	Matrix J = zeros(n, n);

	double x1 = X.at[0][0];
	double x2 = X.at[1][0];

	/* MATLAB CODE
	function J = myJacob(x)
		J = [-1 / 4 * (exp(x(1) / 2) - exp(-x(1) / 2)),		1;
			18 * x(1),										50 * x(2)];
	end
	*/

	// [TO-DO] YOUR CODE GOES HERE
	//J.at[0][0] =_____________;
	//J.at[0][1] =_____________;
	//J.at[1][0] =_____________;
	//J.at[1][1] =_____________;

	
	return J;
}