function F=myFuncEx2_student(Z)

F=zeros(3,1);
th=Z(1);
dx=Z(2);
dy=Z(3);
x0=0;y0=100; x1=0; y1=-100;
x_new0=50;y_new0=186.6025; x_new1=150; y_new1=13.3975;


% [TO-DO] Define Function F
% F=_________;     % 3x1 vector for this exercise


end