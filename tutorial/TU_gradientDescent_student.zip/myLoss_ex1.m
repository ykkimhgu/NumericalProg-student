function L = myLoss_ex1(x)

L= x.^2-4.*x+6;

end



    