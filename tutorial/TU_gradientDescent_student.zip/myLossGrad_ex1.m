function dL= myLossGrad_ex1(x)

dL=2.*x-4;


end