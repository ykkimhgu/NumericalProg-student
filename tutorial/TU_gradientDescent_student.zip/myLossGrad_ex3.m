function dE= myLossGrad_ex3(W,X,Y)

%% Given
a0=W(1);
a1=W(2);
T=X;
P=Y;
N=length(T);

%% Initialization
dE=[0;0];

%% Error Check for Nx==Ny.


%% Loss Function
%loss_grad=@(Z) [2./n.*(sum(r)) 2./n.*(sum(x*r)];
for k=1:N
    r=(a1*T(k)+a0)-P(k);   % or   r=P(k)-(a1*T(k)+a0);

    % [TO-DO] 
    % dE=_________
end



end