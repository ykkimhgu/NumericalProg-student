function dL= myLossGrad_ex1_student(x)

dL=2.*x-4;


end