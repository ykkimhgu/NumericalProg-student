function dL= myLossGrad_ex2_student(Z)

dL= [0;0];

% [TO-DO] Gradident of Loss Function 
% L=@(x,y) 3*(x-2).^2+(y-2).^2;  
% What is  grad_L  ?

% dL= [________;
%     _________];

end