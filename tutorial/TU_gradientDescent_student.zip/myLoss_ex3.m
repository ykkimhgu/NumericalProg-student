function E = myLoss_ex3(W,X,Y)

%% Given
a0=W(1);
a1=W(2);
T=X;
P=Y;
N=length(T);

%% Initialization
E=0;

%% Error Check for Nx==Ny.

%% Loss Function
% E=(sum(r.^2))
for k=1:N
    r=(a1*T(k)+a0)-P(k);
    %r=P(k)-(a1*T(k)+a0);
   
    % [TO-DO] 
    % E=_________
    
end


end



    