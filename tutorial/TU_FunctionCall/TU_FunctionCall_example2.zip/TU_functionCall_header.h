

/*----------------------------------------------------------------\
@ Numerical Methods by Young-Keun Kim - Handong Global University

Author           : [YOUR NAME]
Created          : 26-03-2018
Modified         : 18-03-2024
Language/ver     : C++ in MSVS2019

Description      : Temporary Header File for TU Function Call
----------------------------------------------------------------*/

#pragma once

#include "stdio.h"
#include "stdlib.h"



void func_call(double func(const double x), double xin)
{
	double y = func(xin);
	printf("Y_out = %f \n", y);
}