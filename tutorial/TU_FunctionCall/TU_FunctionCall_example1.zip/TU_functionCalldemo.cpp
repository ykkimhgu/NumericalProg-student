/*-------------------------------------------------------------------------------\
@ Numerical Programming by Young-Keun Kim - Handong Global University

Author           : Y.K.Kim
Created          : 2018-03-20
Modified         : 2024-08-20
Language/ver     : C++ in MSVS2019

Description      : Tutorial code for Calling Functions
-------------------------------------------------------------------------------*/


#include "stdio.h"
#include "stdlib.h"
#include "TU_functionCall_header.h"


// These are defined in TU_functionCall_header.h
// double myFunc(const double x);
// void func_call(double xin);

// How to change the function equation in myFunc()
// if myFunc() is defined in library header file?
//
// Q2) What if myFunc2() is needed to be used?
// What do you need to modify in TU_functionCall_header.h ?


void main()
{
	double  xin = 2.5;
	func_call(xin);
}