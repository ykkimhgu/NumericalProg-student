

/*----------------------------------------------------------------\
@ Numerical Methods by Young-Keun Kim - Handong Global University

Author           : [YOUR NAME]
Created          : 26-03-2018
Modified         : 18-03-2024
Language/ver     : C++ in MSVS2019

Description      : Temporary Header File for TU Function Call
----------------------------------------------------------------*/

#pragma once

#include "stdio.h"
#include "stdlib.h"

double myFunc(const double x) {
	double y = x * x;
	return y;
}

double myFunc2(const double x) {
	double y = x * x * x;
	return y;
}

void func_call(double xin)
{
	double y = myFunc(xin);
	printf("Y_out = %f \n", y);
}