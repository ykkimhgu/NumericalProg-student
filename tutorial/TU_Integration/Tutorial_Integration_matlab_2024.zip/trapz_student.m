function I = trapz_student(x,y)
%  함수 자세한 설명 위치
% Composite Trapezoidal Method
% Input Variables:
%   * Fun Name for the function to be integrated.
%   (Fun is assumed to be written with element-by-element calculations.).
%   * a  Lower limit of integration.
%   * b  Upper limit of integration.
%   * N  Number of subintervals.
% Output Variable:
% * I  Value of the integral.

    if (nargin ~=2)
        error(message('Invalid Argument'));
    end
    
    N=length(x);
    
    I=0; % [TO-DO] YOUR CODE GOES HERE
    
    for k=1:N-1
        %I=_____________%% [TO-DO] YOUR CODE GOES HERE
    end


end

