function [t, y] = odeRK2_student(gradF,a,b,h,y0)
% Description:
% % [TO-DO] Write Comment Section 
% % [TO-DO] Write Comment Section 
% % [TO-DO] Write Comment Section 
%
% Input variables:
% gradF:    Name of a function file that calculates dy/dt.  
% % [TO-DO] Write Comment Section 
% % [TO-DO] Write Comment Section 
% % [TO-DO] Write Comment Section 





    % Variable Initialization
    N = (b-a)/h;
    y=zeros(1,N+1);
    t=zeros(1,N+1);

    % Initial Condition
    t(1) = a;  y(1) = y0;
    

    % RK Design Parameters    
    alpha=1;
    beta=1;
    C1=0.5;
    C2=0.5;

    % ODE Solver
    for i = 1:N
        t(i+1) = t(i) + h;
        K1 = gradF(t(i),y(i));
      
    
        % calculate t2=t(i)+alpha*h
        % [TO-DO] your code goes here    
        % t2=___________________

        % calculate y2=y(i)+ beta*K1*h
        % [TO-DO] your code goes here    
        % y2=___________________

        % Calculate: K2   using t2 and y2
        % [TO-DO] your code goes here    
        % K2=___________________

        % Estimate: y(i+1)
        % [TO-DO] your code goes here    
        % y(i+1)=___________________

        
    end

end  % END OF FUNCTION