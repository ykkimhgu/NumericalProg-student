function [W, loss]=gradientDescent(lossFunc, lossGradFunc, X,Y, Winit, eta)
% Train Linear Regression Model (Gradient Descent)

    % Gradient Descent Configuration
    itrMax=500;
    
    
    % Initialization
    W=Winit;    
    loss=zeros(itrMax,1);
    
    for k=1:itrMax        
        % Update x with Gradient Descent
        gradLoss=lossGradFunc(W,X,Y);
        W=W-eta.*gradLoss;
        
        % Calculate Loss over iteration
        loss(k)=lossFunc(W,X,Y);
            
        if(~mod(k,10))
            fprintf("Iter =%d \t w0=%0.3f\t w1=%0.3f\t loss=%0.8f\n",k,W(1),W(2),loss(k))
        end

    end

end