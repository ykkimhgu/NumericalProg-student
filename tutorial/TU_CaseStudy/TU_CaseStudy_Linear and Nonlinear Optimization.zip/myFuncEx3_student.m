function F=myFuncEx3_student(Z)
% Functions for Simple Euclidean Transformation - 2D

    % Initial  Points
    P = [  0   100;
           0  -100;
           0     0 ];  
    
    P1x=P(1,1); P1y=P(1,2); 
    P2x=P(2,1); P2y=P(2,2); 
    P3x=P(3,1); P3y=P(3,2);    
    
    % Final transformed points
    P_new = [  50   186.6025;
              150    13.3975;
              100   100 ];
    
    P1x_new=P_new(1,1); P1y_new=P_new(1,2); 
    P2x_new=P_new(2,1); P2y_new=P_new(2,2); 
    P3x_new=P_new(3,1); P3y_new=P_new(3,2); 
    
    th=Z(1);
    dx=Z(2);
    dy=Z(3);    

    F=zeros(6,1);

    % Define Function F
    % [TO-DO]     
    % F=[P1x*cos(th) - P1y*sin(th) + dx-P1x_new;
    %    .... ]
    

end



