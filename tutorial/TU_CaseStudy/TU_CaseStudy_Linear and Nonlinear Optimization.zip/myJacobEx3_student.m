function J=myJacobEx3_student(Z)
% Jacobian matrix for Simple Euclidean Transformation - 2D

th=Z(1);
dx=Z(2);
dy=Z(3);

% Initial  Points
P = [  0   100;
       0  -100;
       0     0 ];


P1x=P(1,1); P1y=P(1,2); 
P2x=P(2,1); P2y=P(2,2); 
P3x=P(3,1); P3y=P(3,2); 

J=zeros(6,3);


% Define Jacobian Matrix
% [TO-DO] 
% J = _____________________
% J=[ -P1y*cos(th) - P1x*sin(th), 1,  0;
%    .... ]


end