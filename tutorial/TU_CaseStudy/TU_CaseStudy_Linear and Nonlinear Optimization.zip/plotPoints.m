function plotPoints(p,p_new,Z)
% Plot Points before and after Transformation


theta = Z(1);
dx = Z(2);
dy = Z(3);

c = cos(theta);
s = sin(theta);

% After transformation
p_est = zeros(size(p));
for i = 1:3
    x = p(i,1);
    y = p(i,2);
    p_est(i,1) = c*x - s*y + dx;
    p_est(i,2) = s*x + c*y + dy;
end

% Plot
figure('Name','Point Transformation Result');
hold on; grid on; axis equal;

plot(p(:,1), p(:,2), 'ko', 'MarkerFaceColor','k', 'DisplayName','Source Points');
plot(p_new(:,1), p_new(:,2), 'r*', 'MarkerSize',12, 'DisplayName','Target Final Points');
plot(p_est(:,1), p_est(:,2), 'bs', 'MarkerSize',10, 'DisplayName','Estimated Points');

legend;
xlabel('X coordinate');
ylabel('Y coordinate');
title('Transformation Result');

end