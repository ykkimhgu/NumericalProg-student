function F=myFuncEx2(th,dx,dy)
x0=0;y0=100; x1=0; y1=-100;

x_new0=50;y_new0=186.6025; x_new1=150; y_new1=13.3975;

F =[x0*cos(th)- y0*sin(th) + dx-x_new0 
    x0*sin(th) + y0*cos(th) + dy-y_new0
    x1*cos(th) - y1*sin(th) + dx-x_new1];
end