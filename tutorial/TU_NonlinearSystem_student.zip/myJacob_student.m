function J=myJacob(th,dx,dy)
x0=0; y0=100; x1=0; y1=-100;

J=[-y0*cos(th) - x0*sin(th), 1,  0;
    x0*cos(th) - y0*sin(th),  0, 1;
    -y1*cos(th) - x1*sin(th), 1,  0];
end