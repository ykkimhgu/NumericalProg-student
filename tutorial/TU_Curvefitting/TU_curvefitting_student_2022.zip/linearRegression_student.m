function [a1,a0] = linearRegression_student(x, y)
% LinearRegration calculates the coefficients a1 and a0 of the linear
% equation y = a1*x + a0 that best fit n data points.
% Input variables:
% x    A vector with the coordinates x of the data points.
% y    A vector with the coordinates y of the data points.
% Output variable:
% a1   The coefficient a1.
% a0   The coefficient a0.


%% Your code goes here

% y = a1*x + a0 
a1=0;
a0=0;

%   1. Get data sets of (x, y),  k=1 to m

%   2. Check m=length(X) and length(Y)

%   3. Is length(X)~= length(Y) ? Exit: Continue 

%   4. Initialize Sx, Sxx, Sy, Sxy

%   5. Solve for Sx, Sxx, Sy, Sxy,  for k=1 to m

%   6. Solve for a1, a2
 
%   7. Return a1, a2
 
    
end   % end of function