function Zopt = polyFit_student(x, y,n)
% Calculates the coefficients of polynomial that best fits n data points.
% This is for explanation purpose. You should make it more efficient in
% terms of reducing iteration numbers
%
% Input variables:
%   x: A vector with the coordinates x of the data points.
%   y: A vector with the coordinates y of the data points.
% Output variables:
%   Pcoef=[....a4 a3 a2 a1 a0] 
%
% Number of Iteration:  (2*n+1)*(m)+(n+1)*(n+1)+(n+1)*(m)
% A: (m) by (n+1) //  A'A: (n+1) by (n+1)
% number of data sets m
% Polynomial order ...+(a4)x^4+(a3)x^3+...+(a1)x+a0.
% z=S\b =inv(S)*b  where S=A'A, b=(A'y)



%% Pseudocode
%   1. Get data sets of (x(k), y(k)), polynomial order n

%   2. Calculate m=length(X) and my=length(Y)

%   3. Is length(X)~= length(Y) ? Exit: Continue 

%   4. Is m<(n+1) or n<1 ? Exit: Continue 

%   5. Initialize S:(n+1)x(n+1), b:(n+1)x1 , z:(n+1)x1

%   6. Calculate SX(i)=sum(x.^(i)), for i=0 to 2n  #(2n+1)

%   7. Construct S with SX(i). 
    % S(i,j)= SX(???),  for i = 1:n+1  and  for j=1:n+1

%   8. Construct vector b=(A'y) as
    % Calculate b(j)=sum(y*(x^(j))), for j=0 to n  #(n+1)
    
%   9. Calculate optimal Z=inv(S)*(b)
    % Zopt=[....a4 a3 a2 a1 a0] , (n+1)x1
  



%% Your code goes here

%   1. Get data sets of (x(k), y(k)), polynomial order n
%   2. Calculate m=length(X) and my=length(Y)
    m = length(x);
    my = length(y);
    Zopt=zeros(1,n+1);

%   3. Is length(X)~= length(Y) ? Exit: Continue 
%   4. Is m<(n+1) or n<1 ? Exit: Continue 
    if m ~= my
        disp('ERROR: The number of elements in x must be the same as in y.')
        Zopt = 'Error';
        return
    end
    
%   5. Initialize S:(n+1)x(n+1), b:(n+1)x1 , z:(n+1)x1
    SX=zeros(n+1,n+1); Sxy=zeros(n+1,1); Zopt=zeros(n+1,1);
    S=zeros(n+1,n+1);  b=zeros(n+1,1); 
        
%   6. Calculate SX(i)=sum(x.^(i)), for i=0 to 2n  #(2n+1)
    for i=0:2*n
        SXtemp=0;
        for k=1:m
            % SXtemp=__________
            % your code goes here
        end
        SX(i+1)=SXtemp;         % Index start from 1 in MATALB
    end
    
%   7. Construct S with SX(i).  
    for i = 1:n+1  
        for j=1:n+1
            %S(i,j)=_______________ 
            % your code goes here  
        end
    end

         
%   8. Construct vector b=(A'y) as
    % First, calculate Sxy(j)=sum(y*(x^(j))), for j=n to 0  #(n+1)
    for j=n:-1:0
        Sxytemp=0;
        for k=1:m
            % Sxytemp=___________;
            % your code goes here  
        end
        Sxy(j+1,1)=Sxytemp;     % Index start from 1    
    end
   % Then, b(i,1)=Sxy((n+1)-i+1);  for i=1 to n+1
    for i = 1:n+1  
      % b(i,1)=___________;     
      % your code goes here  
    end

    
%   9. Calculate optimal Z=inv(S)*(b)
    % where z=[a(n).... a(2) a(1) a(0)] , (n+1)x1
    Zopt=(S\b)';
    
   

end