function Zopt = expfit_student(X, Y)
% This  calculates the coefficients c1 and c0 of  f(x)=c0*exp(c1*t)

% Input variables:
% x    A vector with the coordinates x of the data points.
% y    A vector with the coordinates y of the data points.
% Output variable: Z=[c1, c0]
% c1   The coefficient a1.
% c0   The coefficient a0.



%% Pseudocode
% write pseudocode

    
% Return z=[c0, c1];


end