function [a0,a1] = linearFit_student(X, Y)

% LinearRegration calculates the coefficients a1 and a0 of the linear
% equation y = a1*x + a0 that best fit n data points.
% Input variables:
% x    A vector with the coordinates x of the data points.
% y    A vector with the coordinates y of the data points.
% Output variable:
% a1   The coefficient a1.
% a0   The coefficient a0.


%% Your code goes here

% y = a1*x + a0 
a1=0;
a0=0;

%   1. Get data sets of (xk, yk)
%   2. Check m=length(X) and length(Y)
    m = length(X);
    my = length(Y);
       
%   3. Is length(X)~= length(Y) ? Exit: Continue 
    if ((m ~= my) || (m==1))
        disp('ERROR: The number of elements in x must be the same as in y.')
        a1 =0, a0=0;
    else
        
%   4. Initialize Sx, Sxx, Sy, Sxy
        Sx=0; Sxx=0; Sxy=0;Sy=0;  


%   5. Solve for Sx, Sxx, Sy, Sxy,  for k=1 to m

%   6. Solve for a1, a2
 
%   7. Return a1, a2
 
    
end   % end of function