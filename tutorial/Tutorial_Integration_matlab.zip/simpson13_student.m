function [I]=simpson13_student(x,y)
% Simpson 1/3 numerically integrate using the Composite Simpson Method.
% Input Variables:
% * x 1D array 
% * y 1D array
%
% Output Variable:
% * I  Value of the integral.
m=length(x);
N=m-1;
h = x(2)-x(1);

% Composite simpson
I=0;

%I=_____________%% [TO-DO] YOUR CODE GOES HERE

end