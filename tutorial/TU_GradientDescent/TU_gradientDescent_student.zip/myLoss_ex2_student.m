function L = myLoss_ex2_student(Z)

L=0;

% [TO-DO] Loss Function 
% L=@(x,y) 3*(x-2).^2+(y-2).^2;  
% L=_______________

end



    