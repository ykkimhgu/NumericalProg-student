function L = myLoss_ex1_student(x)

L= x.^2-4.*x+6;

end



    