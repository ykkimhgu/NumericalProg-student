function L = myLoss_ex2_student(W)
    L=0;    
    x=W(1);
    y=W(2);
    
    %% Function L(x)
    % [TO-DO] 
    % L=_________________;

end



    