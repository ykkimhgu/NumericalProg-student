function dL= myLossGrad_ex2_student(W)
    dL= [0;0];
    x=W(1);
    y=W(2);

    %% Function dL(x,y)
    % [TO-DO] 
    % dL=[ dL/dX ; dL/dY];
    % dL=__________________
    
end