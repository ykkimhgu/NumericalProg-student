function W_un= unnormalize(W,X)
    
    % Initialization
    D=length(W);    
    W_un= zeros(D,1);
    W_un_bias=0;

    maxX = max(X);
    minX = min(X);
    % Unormalize coefficients
    for p=2:D
        W_un(p) = W(p)/(maxX(p-1)-minX(p-1));
        W_un_bias=W_un_bias+W_un(p)*minX(p-1);
    end

    % Unormalize bias
    W_un(1)=W(1)-W_un_bias;
end