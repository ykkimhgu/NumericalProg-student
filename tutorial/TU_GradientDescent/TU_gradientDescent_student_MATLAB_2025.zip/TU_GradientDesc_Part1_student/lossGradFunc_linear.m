function dE= lossGradFunc_linear(W,X,Y)

    %% Initialization
    [M,D]=size(X);    
    dE=zeros(D+1,1);  % D-dim+bias  
    
    % X should be MxD 
    if (D>M)
        X=X'; 
    end
    
    % Create matrix A=[ 1, X1, X2, .., XD]    
    A=[ones(M,1), X];  % M x (D+1)

    
    %% Loss Function
    for k=1:M        
        Yhat=A(k,:)*W;    % Yhat=1*W(1)+X(k,1)*W(2)+X(k,2)*W(3);
        r=Y(k)-Yhat;
        % dE=[r*A(k,1); r*A(k,2); ...;r*A(k,D+1)] = [r*1; r*X(k,1); ...;r*X(k,D)]
        dE=dE+r*A(k,:)';   
    end
    dE=(-2*dE)/M;
end