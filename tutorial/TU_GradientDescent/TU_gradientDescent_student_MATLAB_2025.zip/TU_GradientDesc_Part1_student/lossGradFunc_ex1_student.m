function dE= lossGradFunc_ex1_student(W,X,Y)

    %% Initialization
    a0=W(1);
    a1=W(2);
    M=length(X);
    dE=[0;0];
    
    % Create matrix A=[ 1, X]    
    % A=[ones(M,1), X];    
    %% Loss Gradient Function
    for k=1:M
        % [TO-DO]
        % [TO-DO]        
        % dE=____;   
    end

    dE=(-2.*dE)./M;
end


