function E = lossFunc_ex1_student(W,X,Y)

    %% Initialization
    a0=W(1);
    a1=W(2);
    M=length(X);
    E=0;

    %% Loss Function
    for k=1:M
        % [TO-DO]  
        % E= __________
    end
    E=E/M;

end



    