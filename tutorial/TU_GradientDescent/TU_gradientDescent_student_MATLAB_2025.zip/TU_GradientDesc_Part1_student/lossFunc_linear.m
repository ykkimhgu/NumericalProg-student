function E = lossFunc_linear(W,X,Y)

    %% Initialization
    [M,D]=size(X);           
    E=0;

    % Create matrix A=[ 1, X1, X2, .., XD]    
    A=[ones(M,1), X];  % M x (D+1)
    
    %% Loss Function
    for k=1:M
        Yhat=A(k,:)*W;    % Yhat=1*W(1)+X(k,1)*W(2)+X(k,2)*W(3);
        r=Y(k)-Yhat;        
        E=E+r^2;
    end
    E=E/M;

end



    