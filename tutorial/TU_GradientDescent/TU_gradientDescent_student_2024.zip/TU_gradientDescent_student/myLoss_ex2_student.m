function L = myLoss_ex2_student(W)

    L=0;
    x=W(1);
    y=W(2);
    
    % [TO-DO] Loss Function 
    % L=_______________

end



    