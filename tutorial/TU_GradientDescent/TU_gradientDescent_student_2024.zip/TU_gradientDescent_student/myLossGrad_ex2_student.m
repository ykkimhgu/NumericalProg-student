function dL= myLossGrad_ex2_student(W)

    x=W(1);
    y=W(2);
    dL= [0;0];

    % [TO-DO] Gradident of Loss Function 
    % dL= [________;
    %     _________];

end
